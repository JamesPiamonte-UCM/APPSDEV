﻿namespace FormAct
{
    partial class frmPersonInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblname = new System.Windows.Forms.Label();
            this.lbladdress = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblgender = new System.Windows.Forms.Label();
            this.lblbirthdate = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblcivilstatus = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblfullname = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.dtpbirthdate = new System.Windows.Forms.DateTimePicker();
            this.cbogender = new System.Windows.Forms.ComboBox();
            this.cbocivilstatus = new System.Windows.Forms.ComboBox();
            this.lbldisplayfullname = new System.Windows.Forms.Label();
            this.btndisplay = new System.Windows.Forms.Button();
            this.btnclose = new System.Windows.Forms.Button();
            this.btnincreasewidth = new System.Windows.Forms.Button();
            this.btndecreasewidth = new System.Windows.Forms.Button();
            this.btncenterform = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.Location = new System.Drawing.Point(40, 36);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(53, 19);
            this.lblname.TabIndex = 20;
            this.lblname.Text = "Name";
            this.lblname.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbladdress
            // 
            this.lbladdress.AutoSize = true;
            this.lbladdress.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladdress.Location = new System.Drawing.Point(40, 65);
            this.lbladdress.Name = "lbladdress";
            this.lbladdress.Size = new System.Drawing.Size(73, 19);
            this.lbladdress.TabIndex = 21;
            this.lbladdress.Text = "Address";
            this.lbladdress.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 0;
            this.label3.Click += new System.EventHandler(this.label2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 0;
            this.label4.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblgender
            // 
            this.lblgender.AutoSize = true;
            this.lblgender.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgender.Location = new System.Drawing.Point(40, 121);
            this.lblgender.Name = "lblgender";
            this.lblgender.Size = new System.Drawing.Size(65, 19);
            this.lblgender.TabIndex = 23;
            this.lblgender.Text = "Gender";
            this.lblgender.Click += new System.EventHandler(this.label5_Click);
            // 
            // lblbirthdate
            // 
            this.lblbirthdate.AutoSize = true;
            this.lblbirthdate.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbirthdate.Location = new System.Drawing.Point(39, 93);
            this.lblbirthdate.Name = "lblbirthdate";
            this.lblbirthdate.Size = new System.Drawing.Size(79, 19);
            this.lblbirthdate.TabIndex = 22;
            this.lblbirthdate.Text = "Birthdate";
            this.lblbirthdate.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(40, 125);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 13);
            this.label7.TabIndex = 1;
            this.label7.Click += new System.EventHandler(this.label6_Click);
            // 
            // lblcivilstatus
            // 
            this.lblcivilstatus.AutoSize = true;
            this.lblcivilstatus.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcivilstatus.Location = new System.Drawing.Point(39, 149);
            this.lblcivilstatus.Name = "lblcivilstatus";
            this.lblcivilstatus.Size = new System.Drawing.Size(95, 19);
            this.lblcivilstatus.TabIndex = 24;
            this.lblcivilstatus.Text = "Civil Status";
            this.lblcivilstatus.Click += new System.EventHandler(this.label8_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(40, 149);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 13);
            this.label9.TabIndex = 2;
            this.label9.Click += new System.EventHandler(this.label8_Click);
            // 
            // lblfullname
            // 
            this.lblfullname.AutoSize = true;
            this.lblfullname.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfullname.Location = new System.Drawing.Point(40, 179);
            this.lblfullname.Name = "lblfullname";
            this.lblfullname.Size = new System.Drawing.Size(85, 19);
            this.lblfullname.TabIndex = 25;
            this.lblfullname.Text = "Full Name";
            this.lblfullname.Click += new System.EventHandler(this.label10_Click);
            // 
            // txtname
            // 
            this.txtname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtname.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(149, 35);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(225, 20);
            this.txtname.TabIndex = 1;
            this.txtname.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtaddress
            // 
            this.txtaddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaddress.Location = new System.Drawing.Point(149, 61);
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(225, 20);
            this.txtaddress.TabIndex = 2;
            this.txtaddress.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // dtpbirthdate
            // 
            this.dtpbirthdate.Location = new System.Drawing.Point(149, 91);
            this.dtpbirthdate.Name = "dtpbirthdate";
            this.dtpbirthdate.Size = new System.Drawing.Size(225, 20);
            this.dtpbirthdate.TabIndex = 3;
            this.dtpbirthdate.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // cbogender
            // 
            this.cbogender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbogender.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbogender.FormattingEnabled = true;
            this.cbogender.Items.AddRange(new object[] {
            "--SELECT GENDER--",
            "Male",
            "Female"});
            this.cbogender.Location = new System.Drawing.Point(149, 117);
            this.cbogender.Name = "cbogender";
            this.cbogender.Size = new System.Drawing.Size(225, 21);
            this.cbogender.TabIndex = 4;
            this.cbogender.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // cbocivilstatus
            // 
            this.cbocivilstatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbocivilstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbocivilstatus.FormattingEnabled = true;
            this.cbocivilstatus.Items.AddRange(new object[] {
            "--SELECT CIVIL STATUS--",
            "Single",
            "Married",
            "Complicated",
            "Widowed",
            "Divorced",
            "Separated"});
            this.cbocivilstatus.Location = new System.Drawing.Point(149, 150);
            this.cbocivilstatus.Name = "cbocivilstatus";
            this.cbocivilstatus.Size = new System.Drawing.Size(225, 21);
            this.cbocivilstatus.TabIndex = 5;
            this.cbocivilstatus.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // lbldisplayfullname
            // 
            this.lbldisplayfullname.BackColor = System.Drawing.Color.Gray;
            this.lbldisplayfullname.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldisplayfullname.ForeColor = System.Drawing.Color.White;
            this.lbldisplayfullname.Location = new System.Drawing.Point(149, 183);
            this.lbldisplayfullname.Name = "lbldisplayfullname";
            this.lbldisplayfullname.Size = new System.Drawing.Size(225, 19);
            this.lbldisplayfullname.TabIndex = 6;
            this.lbldisplayfullname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbldisplayfullname.Click += new System.EventHandler(this.label11_Click);
            // 
            // btndisplay
            // 
            this.btndisplay.BackColor = System.Drawing.Color.Red;
            this.btndisplay.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndisplay.ForeColor = System.Drawing.Color.White;
            this.btndisplay.Location = new System.Drawing.Point(43, 227);
            this.btndisplay.Name = "btndisplay";
            this.btndisplay.Size = new System.Drawing.Size(121, 42);
            this.btndisplay.TabIndex = 7;
            this.btndisplay.Text = "DISPLAY";
            this.btndisplay.UseVisualStyleBackColor = false;
            this.btndisplay.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnclose
            // 
            this.btnclose.BackColor = System.Drawing.Color.Yellow;
            this.btnclose.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclose.ForeColor = System.Drawing.Color.Black;
            this.btnclose.Location = new System.Drawing.Point(183, 227);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(121, 42);
            this.btnclose.TabIndex = 8;
            this.btnclose.Text = "CLOSE";
            this.btnclose.UseVisualStyleBackColor = false;
            this.btnclose.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnincreasewidth
            // 
            this.btnincreasewidth.BackColor = System.Drawing.Color.Green;
            this.btnincreasewidth.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnincreasewidth.ForeColor = System.Drawing.Color.White;
            this.btnincreasewidth.Location = new System.Drawing.Point(44, 284);
            this.btnincreasewidth.Name = "btnincreasewidth";
            this.btnincreasewidth.Size = new System.Drawing.Size(121, 54);
            this.btnincreasewidth.TabIndex = 9;
            this.btnincreasewidth.Text = "INCREASE FORM WIDTH";
            this.btnincreasewidth.UseVisualStyleBackColor = false;
            this.btnincreasewidth.Click += new System.EventHandler(this.button3_Click);
            // 
            // btndecreasewidth
            // 
            this.btndecreasewidth.BackColor = System.Drawing.Color.Blue;
            this.btndecreasewidth.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndecreasewidth.ForeColor = System.Drawing.Color.White;
            this.btndecreasewidth.Location = new System.Drawing.Point(183, 284);
            this.btndecreasewidth.Name = "btndecreasewidth";
            this.btndecreasewidth.Size = new System.Drawing.Size(121, 54);
            this.btndecreasewidth.TabIndex = 10;
            this.btndecreasewidth.Text = "DECREASE FORM WIDTH";
            this.btndecreasewidth.UseVisualStyleBackColor = false;
            this.btndecreasewidth.Click += new System.EventHandler(this.button4_Click);
            // 
            // btncenterform
            // 
            this.btncenterform.BackColor = System.Drawing.Color.Purple;
            this.btncenterform.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncenterform.ForeColor = System.Drawing.Color.White;
            this.btncenterform.Location = new System.Drawing.Point(44, 356);
            this.btncenterform.Name = "btncenterform";
            this.btncenterform.Size = new System.Drawing.Size(121, 54);
            this.btncenterform.TabIndex = 11;
            this.btncenterform.Text = "CENTER FORM";
            this.btncenterform.UseVisualStyleBackColor = false;
            this.btncenterform.Click += new System.EventHandler(this.button5_Click);
            // 
            // frmPersonInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btncenterform);
            this.Controls.Add(this.btndecreasewidth);
            this.Controls.Add(this.btnincreasewidth);
            this.Controls.Add(this.btnclose);
            this.Controls.Add(this.btndisplay);
            this.Controls.Add(this.lbldisplayfullname);
            this.Controls.Add(this.cbocivilstatus);
            this.Controls.Add(this.cbogender);
            this.Controls.Add(this.dtpbirthdate);
            this.Controls.Add(this.txtaddress);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.lblfullname);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lblcivilstatus);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblbirthdate);
            this.Controls.Add(this.lblgender);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbladdress);
            this.Controls.Add(this.lblname);
            this.Name = "frmPersonInfo";
            this.Text = "PERSON INFORMATION ENTRY";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lbladdress;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblgender;
        private System.Windows.Forms.Label lblbirthdate;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblcivilstatus;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblfullname;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.DateTimePicker dtpbirthdate;
        private System.Windows.Forms.ComboBox cbogender;
        private System.Windows.Forms.ComboBox cbocivilstatus;
        private System.Windows.Forms.Label lbldisplayfullname;
        private System.Windows.Forms.Button btndisplay;
        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.Button btnincreasewidth;
        private System.Windows.Forms.Button btndecreasewidth;
        private System.Windows.Forms.Button btncenterform;
    }
}

