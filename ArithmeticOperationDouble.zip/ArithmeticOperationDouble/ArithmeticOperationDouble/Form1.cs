﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ArithmeticOperationDouble
{
    public partial class ArithemticOperationDouble : Form
    {

        double num1, num2;

        public ArithemticOperationDouble()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double sum = 0;

            num1 = Convert.ToDouble(txtnum1.Text);
            num2 = Convert.ToDouble(txtnum2.Text);

            sum = num1 + num2;

            lblresult.Text = sum.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double diff = 0;

            num1 = Convert.ToDouble(txtnum1.Text);
            num2 = Convert.ToDouble(txtnum2.Text);

            diff = num1 - num2;

            lblresult.Text = diff.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double prod = 0;

            num1 = Convert.ToDouble(txtnum1.Text);
            num2 = Convert.ToDouble(txtnum2.Text);

            prod = num1 * num2;

            lblresult.Text = prod.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            double quotient = 0;

            num1 = Convert.ToDouble(txtnum1.Text);
            num2 = Convert.ToDouble(txtnum2.Text);

            quotient = num1 / num2;

            lblresult.Text = quotient.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
