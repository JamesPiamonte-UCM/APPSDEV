﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RankCode
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lblrank_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtrankcode.Text == "A" || txtrankcode.Text == "a")
            {
                MessageBox.Show("Rank 1", "CONFIRMATION", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            }
            else if (txtrankcode.Text == "B" || txtrankcode.Text == "b")
            {
                MessageBox.Show("Rank 2", "CONFIRMATION", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            }
            else if (txtrankcode.Text == "C" || txtrankcode.Text == "c")
            {
                MessageBox.Show("Rank 3", "CONFIRMATION", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            }
            else if (txtrankcode.Text == "D" ||  txtrankcode.Text == "d")
            {
                MessageBox.Show("Rank 4", "CONFIRMATION", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            }
            else
            {
                MessageBox.Show("Invalid Code", "CONFIRMATION", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            }
        }
            

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtrankcode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                btndisplay.Focus();
            }
        }
    }
}
