﻿namespace RankCode
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblrank = new System.Windows.Forms.Label();
            this.txtrankcode = new System.Windows.Forms.TextBox();
            this.btndisplay = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblrank
            // 
            this.lblrank.AutoSize = true;
            this.lblrank.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrank.Location = new System.Drawing.Point(31, 24);
            this.lblrank.Name = "lblrank";
            this.lblrank.Size = new System.Drawing.Size(90, 19);
            this.lblrank.TabIndex = 10;
            this.lblrank.Text = "RankCode";
            this.lblrank.Click += new System.EventHandler(this.lblrank_Click);
            // 
            // txtrankcode
            // 
            this.txtrankcode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtrankcode.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrankcode.Location = new System.Drawing.Point(137, 22);
            this.txtrankcode.Name = "txtrankcode";
            this.txtrankcode.Size = new System.Drawing.Size(187, 26);
            this.txtrankcode.TabIndex = 1;
            this.txtrankcode.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.txtrankcode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtrankcode_KeyPress);
            // 
            // btndisplay
            // 
            this.btndisplay.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndisplay.Location = new System.Drawing.Point(128, 84);
            this.btndisplay.Name = "btndisplay";
            this.btndisplay.Size = new System.Drawing.Size(95, 48);
            this.btndisplay.TabIndex = 2;
            this.btndisplay.Text = "DISPLAY";
            this.btndisplay.UseVisualStyleBackColor = true;
            this.btndisplay.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnexit
            // 
            this.btnexit.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.Location = new System.Drawing.Point(238, 84);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(95, 48);
            this.btnexit.TabIndex = 3;
            this.btnexit.Text = "EXIT";
            this.btnexit.UseVisualStyleBackColor = true;
            this.btnexit.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.btndisplay);
            this.Controls.Add(this.txtrankcode);
            this.Controls.Add(this.lblrank);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "IF ELSE SAMPLE";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblrank;
        private System.Windows.Forms.TextBox txtrankcode;
        private System.Windows.Forms.Button btndisplay;
        private System.Windows.Forms.Button btnexit;
    }
}

