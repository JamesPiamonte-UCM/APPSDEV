﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProductPurchase
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cbocategory.SelectedIndex == 1) //Category Bathsoap
            {
                cboproduct.Items.Clear();

                cboproduct.Items.Insert(0, "-- Select Product--");
                cboproduct.Items.Insert(1, "Safeguard");
                cboproduct.Items.Insert(2, "Bioderm");
                cboproduct.Items.Insert(3, "Papaya Soap");

                cboproduct.SelectedIndex = 0;
                lblprice.Text = "";
            }
            else if (cbocategory.SelectedIndex == 2) //Category Shampoo
            {
                cboproduct.Items.Clear();

                cboproduct.Items.Insert(0, "-- Select Product--");
                cboproduct.Items.Insert(1, "Sunsilk");
                cboproduct.Items.Insert(2, "Head & Shoulder");
                cboproduct.Items.Insert(3, "Palmolive");

                cboproduct.SelectedIndex = 0;
                lblprice.Text = "";
            }
            else if (cbocategory.SelectedIndex == 3) //Category Energy Drink
            {
                cboproduct.Items.Clear();

                cboproduct.Items.Insert(0, "-- Select Product--");
                cboproduct.Items.Insert(1, "Gatorade");
                cboproduct.Items.Insert(2, "Sting");
                cboproduct.Items.Insert(3, "Cobra");

                cboproduct.SelectedIndex = 0;
                lblprice.Text = "";
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            double unitprice;
            if (cbocategory.SelectedIndex == 1) // Bathsoap
            {
                if (cboproduct.SelectedIndex == 1) // safeguard
                {
                    unitprice = 30.00;
                    lblprice.Text = unitprice.ToString("F2");
                }
                else if (cboproduct.SelectedIndex == 2) // bioderm
                {
                    unitprice = 20.00;
                    lblprice.Text = unitprice.ToString("F2");
                }
                else if (cboproduct.SelectedIndex == 3) // Papaya soap
                {
                    unitprice = 25.00;
                    lblprice.Text = unitprice.ToString("F2");
                }
            }
            else if (cbocategory.SelectedIndex == 2) //shampoo
            {
                if (cboproduct.SelectedIndex == 1) // sunsilk
                {
                    unitprice = 7.00;
                    lblprice.Text = unitprice.ToString("F2");
                }
                else if (cboproduct.SelectedIndex == 2) // head & shoulders
                {
                    unitprice = 10.00;
                    lblprice.Text = unitprice.ToString("F2");
                }
                else if (cboproduct.SelectedIndex == 3) // palmolive
                {
                    unitprice = 12.00;
                    lblprice.Text = unitprice.ToString("F2");
                }
            }
            else if (cbocategory.SelectedIndex == 3) //energy drinks
            {
                if (cboproduct.SelectedIndex == 1) // gatorade
                {
                    unitprice = 25.00;
                    lblprice.Text = unitprice.ToString("F2");
                }
                else if (cboproduct.SelectedIndex == 2) // sting
                {
                    unitprice = 30.00;
                    lblprice.Text = unitprice.ToString("F2");
                }
                else if (cboproduct.SelectedIndex == 3) // cobra
                {
                    unitprice = 25.00;
                    lblprice.Text = unitprice.ToString("F2");
                }
            }

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double uprice, amount, total, change;
            int qty;

            uprice = Convert.ToDouble(lblprice.Text);
            qty = Convert.ToInt32(txtquantity.Text);
            amount = Convert.ToDouble(txtamttendered.Text);


            total = uprice * qty;
            change = amount - total;

            lbltotal.Text = total.ToString("C2", new CultureInfo("en-PH"));
            lblchange.Text = change.ToString("C2", new CultureInfo("en-PH"));
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbocategory.SelectedIndex = 0;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            DialogResult resutl = MessageBox.Show("Are you sure you want to exit??", "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resutl == DialogResult.Yes)
            {
                Close();
            }
            else
            {
                cbocategory.SelectedIndex = 0;
                cboproduct.SelectedIndex = 0;

                lblprice.Text = "";
                txtquantity.Text = "";
                lbltotal.Text = "";

                cbocategory.Focus();
            }    
        }

        private void btnproceed_Click(object sender, EventArgs e)
        {
            double uprice, amount, totalchange, total = 0;
            int qty;

            uprice = Convert.ToDouble(lblprice.Text);
            qty = Convert.ToInt32(txtquantity.Text);

            total = uprice * qty;

            lbltotal.Text = total.ToString("C2", new CultureInfo("en-PH"));

        }
    }
}
