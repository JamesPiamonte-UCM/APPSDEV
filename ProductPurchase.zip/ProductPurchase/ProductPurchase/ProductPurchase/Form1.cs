﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProductPurchase
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbocategory.SelectedIndex == 0)
            {
                cboproduct.Enabled = false;
                return;
            }

            // Enable product combo
            cboproduct.Enabled = true;

            // Clear old items
            cboproduct.Items.Clear();

            // Default item
            cboproduct.Items.Add("-- Select Product --");

            // SHAMPOO
            if (cbocategory.SelectedIndex == 1)
            {
                cboproduct.Items.Add("Sunsilk");
                cboproduct.Items.Add("Palmolive");
                cboproduct.Items.Add("Head & Shoulders");
            }
            // BATH SOAP
            else if (cbocategory.SelectedIndex == 2)
            {
                cboproduct.Items.Add("Safeguard");
                cboproduct.Items.Add("Bioderm");
                cboproduct.Items.Add("Papaya Soap");
            }
            // ENERGY DRINK
            else if (cbocategory.SelectedIndex == 3)
            {
                cboproduct.Items.Add("Gatorade");
                cboproduct.Items.Add("Sting");
                cboproduct.Items.Add("Cobra");
            }

            // Set default selection
            cboproduct.SelectedIndex = 0;

            // Reset values
            lblprice.Text = "";
            txtquantity.Text = "";
            lbltotal.Text = "";
            txtamttendered.Text = "";
            lblchange.Text = "";

            // Disable next controls until user proceeds again
            lblprice.Enabled = false;
            txtquantity.Enabled = false;
            btnproceed.Enabled = false;
            txtamttendered.Enabled = false;
            btncompute.Enabled = false;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbocategory.SelectedIndex == 0)
                return;

            double unitprice = 0;
            if (cbocategory.SelectedIndex == 1) // Bathsoap
            {
                if (cboproduct.SelectedIndex == 1) // safeguard
                {
                    unitprice = 30.00;
                    lblprice.Text = unitprice.ToString("F2");
                }
                else if (cboproduct.SelectedIndex == 2) // bioderm
                {
                    unitprice = 20.00;
                    lblprice.Text = unitprice.ToString("F2");
                }
                else if (cboproduct.SelectedIndex == 3) // Papaya soap
                {
                    unitprice = 25.00;
                    lblprice.Text = unitprice.ToString("F2");
                }
            }
            else if (cbocategory.SelectedIndex == 2) //shampoo
            {
                if (cboproduct.SelectedIndex == 1) // sunsilk
                {
                    unitprice = 7.00;
                    lblprice.Text = unitprice.ToString("F2");
                }
                else if (cboproduct.SelectedIndex == 2) // head & shoulders
                {
                    unitprice = 10.00;
                    lblprice.Text = unitprice.ToString("F2");
                }
                else if (cboproduct.SelectedIndex == 3) // palmolive
                {
                    unitprice = 12.00;
                    lblprice.Text = unitprice.ToString("F2");
                }
            }
            else if (cbocategory.SelectedIndex == 3) //energy drinks
            {
                if (cboproduct.SelectedIndex == 1) // gatorade
                {
                    unitprice = 25.00;
                    lblprice.Text = unitprice.ToString("F2");
                }
                else if (cboproduct.SelectedIndex == 2) // sting
                {
                    unitprice = 30.00;
                    lblprice.Text = unitprice.ToString("F2");
                }
                else if (cboproduct.SelectedIndex == 3) // cobra
                {
                    unitprice = 25.00;
                    lblprice.Text = unitprice.ToString("F2");
                }

            }
            txtquantity.Enabled = true;
            txtquantity.Focus();

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double uprice, amount, total, change;
            int qty;

            uprice = Convert.ToDouble(lblprice.Text);
            qty = Convert.ToInt32(txtquantity.Text);
            amount = Convert.ToDouble(txtamttendered.Text);


            total = uprice * qty;
            change = amount - total;

            lbltotal.Text = total.ToString("C2", new CultureInfo("en-PH"));
            lblchange.Text = change.ToString("C2", new CultureInfo("en-PH"));
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbocategory.SelectedIndex = 0;

            // ENABLE ONLY 
            cbocategory.Enabled = true;
            btnclose.Enabled = true;

            // DISABLE ALL OTHERS
            cboproduct.Enabled = false;
            lblprice.Enabled = false;
            txtquantity.Enabled = false;
            btnproceed.Enabled = false;
            txtamttendered.Enabled = false;
            btncompute.Enabled = false;
            lbltotal.Enabled = false;
            lblchange.Enabled = false;

            // FOCUS
            cbocategory.Focus();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            DialogResult resutl = MessageBox.Show("Are you sure you want to exit??", "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resutl == DialogResult.Yes)
            {
                Close();
            }
            else
            {
                cbocategory.SelectedIndex = 0;

                cbocategory.Enabled = true;
                btnclose.Enabled = true;

                // DISABLE ALL OTHERS
                cboproduct.Enabled = false;
                lblprice.Enabled = false;
                txtquantity.Enabled = false;
                btnproceed.Enabled = false;
                txtamttendered.Enabled = false;
                btncompute.Enabled = false;
                lbltotal.Enabled = false;
                lblchange.Enabled = false;

                // Reset value
                cboproduct.Items.Clear();
                lblprice.Text = "";
                txtquantity.Text = "";
                lbltotal.Text = "";
                txtamttendered.Text = "";
                lblchange.Text = "";

                // FOCUS
                cbocategory.Focus();
            }    
        }

        private void btnproceed_Click(object sender, EventArgs e)
        {
            // Validate qty again just in case
            if (string.IsNullOrWhiteSpace(txtquantity.Text))
            {
                MessageBox.Show("Quantity is blank! Please enter a value.");
                txtquantity.Focus();
                return;
            }

            // Convert values
            double unitPrice = Convert.ToDouble(lblprice.Text);
            int qtyPurchased = Convert.ToInt32(txtquantity.Text);

            // Calculate total
            double totalAmount = unitPrice * qtyPurchased;

            // Enable and display total
            lbltotal.Enabled = true;
            lbltotal.Text = totalAmount.ToString("C2", new CultureInfo("en-PH")); // Peso format

            // Enable amount tendered and focus it
            txtamttendered.Enabled = true;
            txtamttendered.Focus();
        }

        private void txtquantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Check if ENTER key is pressed
            if (e.KeyChar == (char)Keys.Enter)
            {
                // Prevent the ding sound
                e.Handled = true;

                // Validate if blank
                if (string.IsNullOrWhiteSpace(txtquantity.Text))
                {
                    MessageBox.Show("Blank not allowed");
                    txtquantity.Focus();
                    txtquantity.SelectAll();
                    return;
                }

                // If valid, enable proceed button and focus
                btnproceed.Enabled = true;
                btnproceed.Focus();
            }
        }

        private void txtamttendered_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Check if ENTER key is pressed
            if (e.KeyChar == (char)Keys.Enter)
            {

                // Validate if blank
                if (string.IsNullOrWhiteSpace(txtamttendered.Text))
                {
                    MessageBox.Show("Blank not allowed");
                    txtamttendered.Focus();
                    txtamttendered.SelectAll();
                    return;
                }

                double uprice, amount, total;
                int qty;

                uprice = Convert.ToDouble(lblprice.Text);
                qty = Convert.ToInt32(txtquantity.Text);
                amount = Convert.ToDouble(txtamttendered.Text);


                total = uprice * qty;
                
                if (total <= amount)
                {

                    lbltotal.Text = total.ToString("C2", new CultureInfo("en-PH"));

                    // If valid, enable proceed button and focus
                    btncompute.Enabled = true;
                    btncompute.Focus();
                }
                else
                {
                    MessageBox.Show("Insufficient Balance");
                }

                
            }
        }
    }
}
