﻿namespace ProductPurchase
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cbocategory = new System.Windows.Forms.ComboBox();
            this.cboproduct = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblprice = new System.Windows.Forms.Label();
            this.txtquantity = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.lbltotal = new System.Windows.Forms.Label();
            this.btncompute = new System.Windows.Forms.Button();
            this.btnclose = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtamttendered = new System.Windows.Forms.TextBox();
            this.lblchange = new System.Windows.Forms.Label();
            this.btnproceed = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(50, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Category";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(50, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(141, 22);
            this.label2.TabIndex = 0;
            this.label2.Text = "Product Name";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // cbocategory
            // 
            this.cbocategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbocategory.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbocategory.FormattingEnabled = true;
            this.cbocategory.Items.AddRange(new object[] {
            "--Select Catergory--",
            "Bathsoap",
            "Shampoo",
            "Energy Drink"});
            this.cbocategory.Location = new System.Drawing.Point(274, 41);
            this.cbocategory.Name = "cbocategory";
            this.cbocategory.Size = new System.Drawing.Size(236, 30);
            this.cbocategory.TabIndex = 1;
            this.cbocategory.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // cboproduct
            // 
            this.cboproduct.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboproduct.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboproduct.FormattingEnabled = true;
            this.cboproduct.Items.AddRange(new object[] {
            "--Select Product--",
            "Bioderm"});
            this.cboproduct.Location = new System.Drawing.Point(274, 85);
            this.cboproduct.Name = "cboproduct";
            this.cboproduct.Size = new System.Drawing.Size(236, 30);
            this.cboproduct.TabIndex = 1;
            this.cboproduct.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(50, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 22);
            this.label3.TabIndex = 0;
            this.label3.Text = "Unit Price";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(50, 185);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(140, 22);
            this.label4.TabIndex = 0;
            this.label4.Text = "Qty. Purchase";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // lblprice
            // 
            this.lblprice.BackColor = System.Drawing.SystemColors.Info;
            this.lblprice.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprice.Location = new System.Drawing.Point(274, 133);
            this.lblprice.Name = "lblprice";
            this.lblprice.Size = new System.Drawing.Size(236, 29);
            this.lblprice.TabIndex = 2;
            this.lblprice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblprice.Click += new System.EventHandler(this.label5_Click);
            // 
            // txtquantity
            // 
            this.txtquantity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtquantity.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtquantity.Location = new System.Drawing.Point(274, 178);
            this.txtquantity.Name = "txtquantity";
            this.txtquantity.Size = new System.Drawing.Size(236, 29);
            this.txtquantity.TabIndex = 3;
            this.txtquantity.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.txtquantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtquantity_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(52, 251);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 22);
            this.label6.TabIndex = 0;
            this.label6.Text = "TOTAL";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // lbltotal
            // 
            this.lbltotal.BackColor = System.Drawing.SystemColors.Info;
            this.lbltotal.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotal.Location = new System.Drawing.Point(274, 237);
            this.lbltotal.Name = "lbltotal";
            this.lbltotal.Size = new System.Drawing.Size(236, 36);
            this.lbltotal.TabIndex = 2;
            this.lbltotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbltotal.Click += new System.EventHandler(this.label7_Click);
            // 
            // btncompute
            // 
            this.btncompute.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncompute.Location = new System.Drawing.Point(215, 409);
            this.btncompute.Name = "btncompute";
            this.btncompute.Size = new System.Drawing.Size(151, 57);
            this.btncompute.TabIndex = 4;
            this.btncompute.Text = "&COMPUTE";
            this.btncompute.UseVisualStyleBackColor = true;
            this.btncompute.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnclose
            // 
            this.btnclose.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclose.Location = new System.Drawing.Point(425, 409);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(158, 57);
            this.btnclose.TabIndex = 5;
            this.btnclose.Text = "CL&OSE";
            this.btnclose.UseVisualStyleBackColor = true;
            this.btnclose.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(52, 295);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(209, 22);
            this.label5.TabIndex = 0;
            this.label5.Text = "AMOUNT TEMDERED";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(50, 354);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 22);
            this.label7.TabIndex = 0;
            this.label7.Text = "CHANGE";
            // 
            // txtamttendered
            // 
            this.txtamttendered.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtamttendered.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtamttendered.Location = new System.Drawing.Point(274, 293);
            this.txtamttendered.Name = "txtamttendered";
            this.txtamttendered.Size = new System.Drawing.Size(236, 29);
            this.txtamttendered.TabIndex = 6;
            this.txtamttendered.TextChanged += new System.EventHandler(this.txtamttendered_TextChanged);
            this.txtamttendered.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtamttendered_KeyPress);
            // 
            // lblchange
            // 
            this.lblchange.BackColor = System.Drawing.SystemColors.Info;
            this.lblchange.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lblchange.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblchange.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblchange.Location = new System.Drawing.Point(274, 353);
            this.lblchange.Name = "lblchange";
            this.lblchange.Size = new System.Drawing.Size(236, 35);
            this.lblchange.TabIndex = 7;
            this.lblchange.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnproceed
            // 
            this.btnproceed.Location = new System.Drawing.Point(526, 178);
            this.btnproceed.Name = "btnproceed";
            this.btnproceed.Size = new System.Drawing.Size(57, 29);
            this.btnproceed.TabIndex = 8;
            this.btnproceed.Text = "Proceed";
            this.btnproceed.UseVisualStyleBackColor = true;
            this.btnproceed.Click += new System.EventHandler(this.btnproceed_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(313, 210);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(160, 17);
            this.label8.TabIndex = 9;
            this.label8.Text = "(Press Enter to Proceed)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(312, 325);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(160, 17);
            this.label9.TabIndex = 9;
            this.label9.Text = "(Press Enter to Proceed)";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(653, 493);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnproceed);
            this.Controls.Add(this.lblchange);
            this.Controls.Add(this.txtamttendered);
            this.Controls.Add(this.btnclose);
            this.Controls.Add(this.btncompute);
            this.Controls.Add(this.txtquantity);
            this.Controls.Add(this.lbltotal);
            this.Controls.Add(this.lblprice);
            this.Controls.Add(this.cboproduct);
            this.Controls.Add(this.cbocategory);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Product Purchase";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbocategory;
        private System.Windows.Forms.ComboBox cboproduct;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblprice;
        private System.Windows.Forms.TextBox txtquantity;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbltotal;
        private System.Windows.Forms.Button btncompute;
        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtamttendered;
        private System.Windows.Forms.Label lblchange;
        private System.Windows.Forms.Button btnproceed;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
    }
}

